# from flask import Flask, render_template, request
# import numpy as np
# import pickle

# app = Flask(__name__)

# # Load the trained model
# with open('random_forest_pkl2.pkl', 'rb') as file:
#     model = pickle.load(file)

# @app.route('/')
# def index():
#     return render_template('index.html')

# @app.route('/predict', methods=['POST'])
# def predict():
#     try:
#         features = [float(request.form[key]) for key in ['N', 'P', 'K', 'ph', 'ec', 'oc', 'S', 'zn', 'fe', 'cu', 'Mn', 'B']]
#         log_transformed = np.log10(np.array(features).reshape(1, -1))
#         prediction = model.predict(log_transformed)[0]
#         classes = {0: 'Less Fertile', 1: 'Fertile', 2: 'Highly Fertile'}
#         result = classes[prediction]
#         return render_template('result.html', result=result)
#     except Exception as e:
#         return render_template('result.html', result=f"Error: {str(e)}")

# if __name__ == '__main__':
#     app.run(debug=True)


from flask import Flask, request, jsonify, render_template
import numpy as np
import pickle
from tensorflow.keras.models import load_model

app = Flask(__name__)

with open('random_forest_pkl2.pkl', 'rb') as file:
    model = pickle.load(file)

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/result', methods=['POST'])
def result():
    try:
        feature_names = [
            'Nitrogen', 'Phosphorus', 'Potassium', 'Soil pH',
            'Electrical Conductivity', 'Organic Carbon', 'Sulphur',
            'Zinc', 'Iron', 'Copper', 'Manganese', 'Boron'
        ]
        features = []
        for name in feature_names:
            value = float(request.form.get(name))
            if value <= 0:
                raise ValueError(f"{name} must be greater than 0 for log transformation.")
            features.append(value)

        log_transformed = np.log10(np.array(features).reshape(1, -1).astype(np.float32))
        prediction = model.predict(log_transformed)[0]
        classes = {0: 'The Data Shows that the Soil is Less Fertile', 1: 'The Data Shows that the Soil is Fertile', 2: 'The Data Shows that the Soil is Highly Fertile'}
        result = classes[prediction]
        return render_template('result.html', result=result)

    except Exception as e:
        return render_template('result.html', result=f"Error: {str(e)}")

if __name__ == "__main__":
    app.run(debug=True)
